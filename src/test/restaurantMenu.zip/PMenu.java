package test;

import java.util.ArrayList;

public abstract class PMenu {
	
	protected static ArrayList<String> kodeMenu = new ArrayList<String>();
	protected static ArrayList<String> namaMenu = new ArrayList<String>();
	protected static ArrayList<Integer> harga = new ArrayList<Integer>();
	
	
	public void deleteMenu(String kodeMenu) {
		this.kodeMenu.remove(this.kodeMenu.indexOf(kodeMenu));
	}
	
	public abstract void showMenu();

	

	public void addMenu(String kodeMenu, String namaMenu, int harga) {
		// TODO Auto-generated method stub
		
	}
	
	
	
}
