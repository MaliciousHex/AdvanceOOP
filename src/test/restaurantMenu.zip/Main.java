package test;
import java.util.Scanner;

public class Main {
	
	RegularMenu regularMenu = new RegularMenu();
	SpecialMenu specialMenu = new SpecialMenu();
	
	private static void cls(){
		for(int i =0 ; i < 32 ; i++){
			System.out.println();
		}
	}
	
	private static void menu(){
		System.out.println("Family Restaurant");
		System.out.println("====================");
		System.out.println("1. Add Regular Menu");
		System.out.println("2. Add Special Menu");
		System.out.println("3. Show All Menu");
		System.out.println("4. Delete Regular Menu");
		System.out.println("5. Delete Special Menu");
		System.out.println("6. Exit");
	}
	
	

	private void deleteSpecialMenu() {
		// TODO Auto-generated method stub
		Scanner scan = new Scanner(System.in);
		cls();
		String kodeMenu = "";
		System.out.println("Delete Special Menu");
		System.out.println("=======================");
		do {
			System.out.print("input menu code[S...]: ");
			kodeMenu = scan.nextLine();
		}while(kodeMenu.length()>4 || kodeMenu.indexOf("S",0)!=0);
		if(specialMenu.kodeMenu.contains(kodeMenu))
		{
			//specialMenu.menuCode.remove(menuCode);
			specialMenu.deleteMenu(kodeMenu);
			System.out.print("delete success");
			scan.nextLine();
		}
		else
		{
			System.out.print("code is wrong");
			scan.nextLine();
		}
		
	}

	private void deleteRegularMenu() {
		// TODO Auto-generated method stub
		Scanner scan = new Scanner(System.in);
		
		cls();
		String kodeMenu = "";
		System.out.println("Delete Regular Menu");
		System.out.println("=======================");
		do {
			System.out.print("input menu code[R...]: ");
			kodeMenu = scan.nextLine();
		}while(kodeMenu.length()>4 || kodeMenu.indexOf("R",0)!=0);
		if(regularMenu.kodeMenu.contains(kodeMenu))
		{
//			regularMenu.menuCode.remove(menuCode);
			regularMenu.deleteMenu(kodeMenu);
			System.out.print("delete success");
			scan.nextLine();
		}
		else
		{
			System.out.print("code is wrong");
			scan.nextLine();
		}
	}

	private void showAllMenu() {
		// TODO Auto-generated method stub
		Scanner scan = new Scanner(System.in);
		cls();
		if(regularMenu.kodeMenu.size()==0 && specialMenu.kodeMenu.size()==0)
		{
			System.out.println("No menu");
			scan.nextLine();
		}
		else {
			regularMenu.showMenu();
			specialMenu.showMenu();
			scan.nextLine();
		}
	}

	private void addSpecialMenu() {
		// TODO Auto-generated method stub
		Scanner scan = new Scanner(System.in);
		
		cls();
		String kodeMenu="";
		String namaMenu="";
		int harga = 0;
		int discount = 0;
		
		System.out.println("add special menu");
    	System.out.println("==================");
    	do
    	{
    		System.out.print("input menu code[S...]: ");
    		kodeMenu=scan.nextLine();
    	}while(kodeMenu.indexOf("S",0)!=0 || kodeMenu.length()>4 ||specialMenu.kodeMenu.contains(kodeMenu));
    	do
    	{
	    	System.out.print("input menu name[5-20]: ");
	    	namaMenu=scan.nextLine();
    	}while(namaMenu.length()<5 || namaMenu.length()>20);
		do
		{
			try
			{
				System.out.print("input menu price[10000-100000]: ");
				harga=scan.nextInt();
			}
			catch(Exception e)
			{
				scan.nextLine();
			}
		}while(harga<10000 || harga>100000);
		do {
			try {
				System.out.print("input menu discount: ");
				discount = scan.nextInt();
			}
			catch (Exception e)
			{
				scan.nextLine();
			}
		}while(discount!=10 && discount!= 25 && discount!=50);
		specialMenu.addMenu(kodeMenu,namaMenu,harga,discount);
		System.out.println("add success");
		
	}

	private void addRegularMenu() {
		// TODO Auto-generated method stub
		Scanner scan = new Scanner(System.in);
		cls();
    	
    	String kodeMenu="";
    	String namaMenu="";
    	int harga = 0;
    	System.out.println("add regular menu");
    	System.out.println("==================");
    	do
    	{
    		System.out.print("input menu code[R...]: ");
    		kodeMenu=scan.nextLine();
    		
    	}while(kodeMenu.length()>4||kodeMenu.indexOf("R",0)!=0|| regularMenu.kodeMenu.contains(kodeMenu));
    	do
    	{
	    	System.out.print("input menu name[5-20]: ");
	    	namaMenu=scan.nextLine();

    	}while(namaMenu.length()<5 || namaMenu.length()>20);
    	do
    	{
    		try
    		{
		    	System.out.print("input menu price[10000-100000]: ");
		    	harga=scan.nextInt();
    		}
    		catch(Exception e)
    		{
    			scan.nextLine();
    		}
    	}while(harga<10000 || harga>100000);
    	regularMenu.addMenu(kodeMenu,namaMenu,harga);
		System.out.println("add success");
		
		
	}
	
	public Main() {
		super();
		// TODO Auto-generated constructor stub
		
		Scanner scan = new Scanner(System.in);
		int choose = 0;
		do {
		cls();
		menu();
		
		
		do{
		try {
			System.out.print("Choice [1-6]");
			choose = scan.nextInt();	
		} catch (Exception e) {
			System.out.println("Must numeric");
		}
		}while(choose < 1 || choose > 6);
		
		switch (choose) {
		case 1:
			addRegularMenu();
			break;
		case 2:
			addSpecialMenu();
			break;
		case 3:
			showAllMenu();
			break;
		case 4:
			deleteRegularMenu();
			break;
		case 5:
			deleteSpecialMenu();
			break;
		default:
			break;
		}
		}while(choose!=6);
	}
	

	public static void main(String[] args) {
		Main main = new Main();
		
		
	}

}
