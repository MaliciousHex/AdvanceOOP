package test;

import java.util.ArrayList;

public class SpecialMenu extends PMenu {
	
	ArrayList<Integer> xdiscount = new ArrayList<Integer>();
	
	public SpecialMenu() {
		super();
		
	}

	public void addMenu(String kodeMenu, String namaMenu, int harga,int discount) {
		// TODO Auto-generated method stub
		
		this.kodeMenu.add(kodeMenu);
		this.namaMenu.add(namaMenu);
		this.harga.add(harga);
		xdiscount.add(discount);
		
	}



	public void showMenu() {
		System.out.println("Special Menu");
		System.out.println("======================");
		for(int i = 0 ; i < kodeMenu.size(); i++) {
			System.out.println(this.kodeMenu.get(i) + this.namaMenu.get(i) + this.harga.get(i) + xdiscount.get(i));
		}
		
	}
	
}
