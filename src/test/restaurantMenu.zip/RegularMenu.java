package test;

public class RegularMenu extends PMenu{
	
	

	public RegularMenu() {
		super();
		// TODO Auto-generated constructor stub
	}

	
	
	public void showMenu() {
		System.out.println("Special Menu");
		System.out.println("======================");
		for(int i = 0 ; i < kodeMenu.size(); i++) {
			System.out.println(this.kodeMenu.get(i) + this.namaMenu.get(i) + this.harga.get(i));
		}
		
	}

	@Override
	public void addMenu(String kodeMenu,String namaMenu,int harga) {
		
		this.kodeMenu.add(kodeMenu);
		this.namaMenu.add(namaMenu);
		this.harga.add(harga);
		
	}
	
	
}
